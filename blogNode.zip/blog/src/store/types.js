// Getters
export const SEARCH_BLOG = 'blog/SEARCH_BLOG'

// Mutations
export const MUTATE_SET_SEARCH_BLOG = 'blog/MUTATE_SET_SEARCH_BLOG'

// Actions
export const SET_SEARCH_BLOG = 'blog/SET_SEARCH_BLOG'
