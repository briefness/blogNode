<template>
  <div class="footer">
    找到属于自己的圈子
  </div>
</template>

<script>
export default {
  name: 'Footer',
  data () {
    return {
    }
  },
  mounted () {},
  methods: {}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.footer {
  height: 50px;
  line-height: 50px;
  width: 100%;
  background-color: #FFF;
  border-top: 1px solid #F0F0F0;
}
</style>
